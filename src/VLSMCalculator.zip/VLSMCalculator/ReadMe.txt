#
# VLSM Calculator Assignment
# Author : Olga Belavina
# Student ID : 058996141

# Date : April 16 2016
#
# The program works on any OS provided that latest version of Java  is installed.


Run VLSMCalculator.jar to use the prog.
You can export table into CSV by going to File -> Export to CSV

NOTE: If you get Java Exception , that means that your JDK is old and not that awesome.




