package belavina6141.gui;

import java.util.EventListener;

/**
 * Created by Olga Belavina on 2016-04-01.
 */
public interface VLSMCalcListener extends EventListener {
    public void VLSMCalclEventOccurred (VLSMCalcEvent e);
}
