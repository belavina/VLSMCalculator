package belavina6141.Controller;

import javax.swing.*;

/**
 * Created by Olga Belavina on 2016-04-09.
 */

public  interface LogUpdate {
    void updateLogLabel(JLabel lbl);
}